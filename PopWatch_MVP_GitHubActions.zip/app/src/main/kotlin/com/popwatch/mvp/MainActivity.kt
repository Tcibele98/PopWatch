package com.popwatch.mvp

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dashboard()
    }

    fun base(): LinearLayout {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(32, 40, 32, 32)
        root.setBackgroundColor(Color.rgb(17,17,26))

        val title = TextView(this)
        title.text = "PopWatch"
        title.textSize = 30f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER
        root.addView(title)

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, 25, 0, 0)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }

    fun text(s: String, size: Float = 16f) {
        val v = TextView(this)
        v.text = s
        v.textSize = size
        v.setTextColor(Color.WHITE)
        v.setPadding(0, 8, 0, 8)
        content.addView(v)
    }

    fun button(s: String, f: () -> Unit) {
        val b = Button(this)
        b.text = s
        b.setOnClickListener { f() }
        content.addView(b)
    }

    fun dashboard() {
        val r = base()
        text("Proteção", 14f)
        text("● ATIVA", 22f)
        text("12 pop-ups detectados", 20f)
        text("3 aplicativos bloqueados", 18f)
        text("Último evento: Shopee • 14:32")
        text("Possível responsável", 14f)
        text("Shopee — Alta probabilidade — 87%", 18f)
        button("Ver aplicativos") { apps() }
        button("Ver estatísticas") { stats() }
        setContentView(r)
    }

    fun apps() {
        val r = base()
        text("Aplicativos suspeitos", 24f)
        text("Shopee", 20f)
        text("Alta probabilidade • 87%")
        text("12 ocorrências hoje")
        button("Detalhes") { details() }
        button("Voltar") { dashboard() }
        setContentView(r)
    }

    fun details() {
        val r = base()
        text("Shopee", 26f)
        text("Possível responsável — Alta probabilidade — 87%", 18f)
        text("Por que o PopWatch suspeita deste app?", 17f)
        text("• O pop-up apareceu enquanto o app estava ativo")
        text("• O comportamento ocorreu 12 vezes hoje")
        text("• 9 ocorrências nos últimos 30 minutos")
        text("• Comportamento compatível com exibição sobre outros apps")
        button("Permitir") { dashboard() }
        button("Bloquear") { dashboard() }
        button("Observar") { dashboard() }
        button("Desinstalar") { dashboard() }
        button("Voltar") { apps() }
        setContentView(r)
    }

    fun stats() {
        val r = base()
        text("Estatísticas", 26f)
        text("Hoje: 12 pop-ups")
        text("Últimos 7 dias: 38 pop-ups")
        text("Maior frequência: 9 eventos em 30 min")
        text("Mais suspeito: Shopee — 87%")
        button("Voltar") { dashboard() }
        setContentView(r)
    }
}
