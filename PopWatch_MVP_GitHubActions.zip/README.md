# PopWatch MVP — GitHub Actions

Protótipo Android preparado para compilação na nuvem.

## Pelo celular
1. Crie um repositório no GitHub.
2. Envie o conteúdo deste projeto.
3. Abra Actions.
4. Selecione Build PopWatch APK.
5. Toque em Run workflow.
6. Aguarde terminar.
7. Abra a execução concluída.
8. Em Artifacts, baixe PopWatch-debug-APK.
9. Extraia e instale app-debug.apk.

## Importante
Esta versão é um MVP com dados simulados. Ainda não detecta nem bloqueia pop-ups reais de outros aplicativos.
